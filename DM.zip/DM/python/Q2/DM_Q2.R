# Load the required libraries
library(editrules)
library(dplyr)

# Load the dirty_iris dataset
dirty_iris <- read.csv("C:/Users/DELL/Desktop/SEM-6/DM/CompletePracticalFile/Q2/dirty_iris.csv")
data(dirty_iris)

# Check the number and percentage of complete observations
complete_rows <- complete.cases(dirty_iris)
n_complete <- sum(complete_rows)
p_complete <- n_complete/nrow(dirty_iris)
cat("Number of complete observations:", n_complete, "\n")
cat("Percentage of complete observations:", round(p_complete*100, 2), "%\n")

# Replace all special values with NA
dirty_iris[dirty_iris == -999] <- NA

# Define the rules in a separate text file and read them
rules <- editfile("C:/Users/DELL/Desktop/SEM-6/DM/CompletePracticalFile/Q2/rules.txt")

# Print the constraint object
print(rules)

# Determine how often each rule is broken
violations <- violatedEdits(rules, dirty_iris)
summary(violations)
barplot(violations)

# Find outliers in sepal length using boxplot and boxplot.stats
boxplot(dirty_iris$Sepal.Length)
outliers <- boxplot.stats(dirty_iris$Sepal.Length)$out
cat("Outliers in Sepal.Length:", paste(outliers, collapse = ", "))

