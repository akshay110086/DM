# Create a vector of 10 random integers between -50 and 50
random_vector <- sample(x = -50:50, size = 10, replace = TRUE)

# Print the vector
print(random_vector)
